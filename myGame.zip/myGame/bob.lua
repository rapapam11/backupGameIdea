anim8 = require("libaries/anim8")

--Create Player Object
local spriteSheet = love.graphics.newImage('sprites/spriteSheet.png')
local playerGrid = anim8.newGrid(144, 144, spriteSheet:getWidth(), spriteSheet:getHeight())


    local bobAnimations = { 
            animDown = anim8.newAnimation(playerGrid('1-8', 3), 0.2),
            animUp = anim8.newAnimation(playerGrid('1-4', 4), 0.2),
            animLeft = anim8.newAnimation(playerGrid('1-8', 2), 0.2),
            animRight = anim8.newAnimation(playerGrid('1-8', 1), 0.2)
           
        }


    local bob = {
            
            x = 400,
            y = 300,
            vx = 0,
            vy = 0,
            speed = 120,
            radius = 25,
            color = {1, 0, 0},  -- red
            sprite = love.graphics.newImage('sprites/spriteSheet.png'),
            direction = "upwards",
            animCurrent = bobAnimations.animDown
        }
        

--Player function tracking and Updating Movement
local function bobMovement()
local Up = love.keyboard.isDown('w') 
local Down = love.keyboard.isDown('s') 
local Left = love.keyboard.isDown('a') 
local Right = love.keyboard.isDown('d')
bob.vy = 0
bob.vx = 0


if Up then bob.vy = bob.vy - bob.speed 
           bob.direction = "upwards"
           bob.animCurrent = bobAnimations.animUp
end
if Down then bob.vy = bob.vy + bob.speed
             bob.direction = "downwards"
             bob.animCurrent = bobAnimations.animDown
end
if Left then bob.vx = bob.vx - bob.speed  
             bob.direction = "leftwards"
             bob.animCurrent = bobAnimations.animLeft
end 
if Right then bob.vx = bob.vx + bob.speed
              bob.direction = "rightwards"
              bob.animCurrent = bobAnimations.animRight
end

playerCollider.collider:setLinearVelocity(bob.vx, bob.vy)
end

-- return Object of Player Object and Movement function 
return {
    bob = bob,
    bobMovement = bobMovement,
    bobAnimations = bobAnimations,
    spriteSheet = spriteSheet
    
}
