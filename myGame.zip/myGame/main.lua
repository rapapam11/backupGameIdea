--Import World
local world = require("world")
playerCollider = world.playerCollider


--Imports Bob (the Player)
local bobPlayer = require("bob")  
local bob = bobPlayer.bob         
local moveBob = bobPlayer.bobMovement
local animBob = bobPlayer.bobAnimations

--Imports the ChasingAI
local chaserAI = require("enemies")
local chaser = chaserAI.chaser_1
local chaser2 = chaserAI.chaser_2

--Import Functions
local allFunctions = require("chaser")
local moveChaser = allFunctions.chaserMove

--first Boot load
function love.load()

love.window.setMode(1280, 720) 
love.graphics.setBackgroundColor(255, 0, 0)
love.graphics.setDefaultFilter("nearest", "nearest")

end


--updated Frequently
function love.update(dt)
gameWorld:update(dt)
moveBob()
bob.x = world.playerCollider.collider:getX()
bob.y = world.playerCollider.collider:getY()
moveChaser(bob, chaser)
moveChaser(bob, chaser2)
bob.animCurrent:update(dt)

end


--all final drawing happens here
function love.draw()
love.graphics.setColor(chaser.color)
love.graphics.print(bob.direction)
love.graphics.circle(chaser.mode, chaser.x, chaser.y, chaser.radius)
love.graphics.circle(chaser2.mode, chaser2.x, chaser2.y, chaser2.radius)
love.graphics.setColor(1, 1, 1)
bob.animCurrent:draw(bobPlayer.spriteSheet, bob.x - 144, bob.y - 144, nil, 2)
gameWorld:draw()

end
