wf = require('libaries/windfield')
gameWorld = wf.newWorld(0, 0)
local bobPlayer = require("bob")
local bob = bobPlayer.bob 


local playerCollider = {
        collider = gameWorld:newBSGRectangleCollider(bob.x, bob.y, 45, 21, 14)
       
}
playerCollider.collider:setFixedRotation(true)
playerCollider.collider:setLinearDamping(5)



return{
    playerCollider = playerCollider
}