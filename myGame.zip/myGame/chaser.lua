--Import The player in order to build logic for the chase
local bobPlayer = require("bob") 
local enemies = require("enemies")
local bob = bobPlayer.bob 


--Create Object for chasing AI



--Simple Chasing Arithmetics 
local function chaserMove (player, chaser)
    local dx = player.x - chaser.x + 48
    local dy = player.y - chaser.y + 48
    local distance = math.sqrt(dx * dx + dy * dy)


    if distance >= 0 then
        -- Normalize direction and move chaser
        dx = dx / distance 
        dy = dy / distance 

        chaser.x = chaser.x + dx * 1
        chaser.y = chaser.y + dy * 1
end
end







-- Return the Chaser Object and the Movement of the ChaserAI
return {
    chaserMove = chaserMove
}
