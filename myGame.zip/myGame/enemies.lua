local chaser_1 = {
           mode = 'fill',
              x = 100,
              y = 100,
         radius = 10,
          color = {0, 1, 0}
}



local chaser_2 = {
           mode = 'fill',
              x = 150,
              y = 150,
         radius = 10,
          color = {0, 1, 0}
}


return {
    chaser_1 = chaser_1,
    chaser_2 = chaser_2
    
}
